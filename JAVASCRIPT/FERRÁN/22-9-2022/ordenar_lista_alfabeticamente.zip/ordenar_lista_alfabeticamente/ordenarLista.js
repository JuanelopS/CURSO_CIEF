// Nos piden ordenar de forma alfábetica la lista de marcas de
// automóviles del html. Hay varias formas de hacerlo, pero
// algunas solo son adecuadas si el código con el que trabajamos
// es muy sencillo.


// Empezamos por obtener la lista, es decir el elemento "ul"
const listaDesordenada_1 = document.getElementById('marcas').children
// Mostramos en consola para verificar que es correcto.
// console.log(listaDesordenada);

// listaDesordenada es el elemento padre, pero realmente nos interesan
// los hijos, los ítems de la lista
const hijosListaDesordenada = listaDesordenada_1.children

// Para guardar la información vamos a necesitar un array 
const arrayMarcas = []

// con Array.from( collection ) podemos tratar la HTMLCollection 
// como un array
Array.from(hijosListaDesordenada).forEach(
    elemento => {
        // console.log(elemento.textContent);
        // añadimos el contenido de los elementos al array
        arrayMarcas.push(elemento.textContent)
    }
)

// ordenamos el array alfabéticamente
arrayMarcas.sort()
// console.log(arrayMarcas);



// // ****** SOLUCIÓN 1 : sustituir el valor de los elementos

// Array.from(listaDesordenada).forEach( (elemento, index) =>{
//     elemento.textContent=arrayMarcas[index];
// })

// // ***************************************************************

// ****** SOLUCIÓN 2 : eliminar y volver a añadir los elementos

// eliminar el contenido original del elemento 'ul', los hijos
// listaDesordenada.replaceChildren();

// // añadir nuevos hijos con los valores correctamente ordenados
// arrayMarcas.forEach(elemento =>{
//     let newElement = document.createElement('li');
//     newElement.textContent = elemento;
//     listaDesordenada.appendChild(newElement);
// })
// // ***************************************************************


// // ****** SOLUCIÓN 3 : cambiar el valor de los elementos de la lista
// for(let i=0; i<listaDesordenada.length;i++){
//     listaDesordenada[i].textContent = arrayMarcas[i];
// }
// // ***************************************************************



// // ****** SOLUCIÓN 4 : sustituir la lista

// // crear una nueva lista
// let newList = document.createElement('ul')

// // añadir los elementos a la lista
// arrayMarcas.forEach( elemento => {
//     let li = document.createElement('li')
//     li.textContent = elemento
//     newList.appendChild(li)
// })

// // obtener el elemento padre
// const divPadre = document.getElementById('div1')

// // reemplazar los elementos
// divPadre.replaceChild(newList, listaDesordenada2)
// // ***************************************************************
