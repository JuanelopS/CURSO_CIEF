window.onload = () => {

    // #lista_frutas -> ul -> children -> li
    const listaImagenes = document.querySelector('#lista_frutas').children;
    // console.log(listaImagenes)

    let total = 0;

    // evento click para cada imagen
    for(let item of listaImagenes){
        item.addEventListener('click', () => {
            // console.log(item.lastElementChild.innerHTML);
            addFruta(item.lastElementChild.innerHTML);
            extractorPrecio(item.lastElementChild.innerHTML);
            actualizarTotal();
        });
    }

    // función añadir fruta al html
    const addFruta = fruta => {
        const carrito = document.getElementById('carrito');
        carrito.insertAdjacentHTML('beforeend', `<p> - ${fruta}</p>`)
    };

    // función extraer el precio del html y sumar el total
    const extractorPrecio = fruta => {
        const regex = /\d+/g;
        const precio = parseFloat(fruta.match(regex).reduce((a, b) => `${a}.${b}`));
        total += precio;
    };

    // mostrar/actualizar total en pantalla
    const actualizarTotal = () => {
        const totalPago = document.querySelector('#total_pago')
        totalPago.innerHTML = `Total a pagar: ${total.toFixed(2)}€`;
    }
};
