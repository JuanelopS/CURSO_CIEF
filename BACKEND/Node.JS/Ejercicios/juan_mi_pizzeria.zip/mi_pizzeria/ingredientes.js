const masa = [{
        "tipo": "normal",
        "precio": "2"
    },
    {
        "tipo": "espelta",
        "precio": "3"
    },
    {
        "tipo": "integral",
        "precio": "2.5"
    },

];

const condimentos = [
    {
        "mozzarella": "1.2",
        "4 quesos": "3.8",
        "salsa tomate" : "0.8",
        "pollo" : "3.5",
        "anchoas" : "4.0",
        "aceitunas" : "1.2"
    },

]

module.exports = {
    masa: masa,
    condimentos: condimentos
}

